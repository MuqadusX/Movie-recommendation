# import os
# import eel

# from engine.features import *
# from engine.command import *

# def start():
    
#     eel.init("www")

#     playAssistantSound()


#     os.system('start msedge.exe --app="http://localhost:8000/index.html"')

#     eel.start('index.html', mode=None, host='localhost', block=True)


import os
import eel

# Assuming you have a playAssistantSound function in your features module
from engine.features import playAssistantSound
# Assuming you have other command functions in your command module
from engine.command import *

def start():
    # Initialize the eel web folder
    eel.init("www")

    # Play assistant sound
    playAssistantSound()

    # Start the browser with the app URL
    os.system('start msedge.exe --app="http://localhost:8000/index.html"')

    # Start the eel server
    eel.start('index.html', mode=None, host='localhost', block=True)

if __name__ == "__main__":
    start()
